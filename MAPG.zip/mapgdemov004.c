
//MAPG demonstration program
//Functions labeled Key_x() are called when the corresponding key is pressed


void Key_i(void)
{
	// Information page

	DisplayControl(0);			//clear previous sprite list

	SetColor(2, .5, .5, .5);	//set screen clear color (r,g,b .5 = mid grey)
	ImageColor(255,255,255);	//set image foreground color

	ImageText("Motion Artifact Pattern Generator (MAPG) demonstration program information page:");	//generate an image containing text
	SpriteAllocate(.01,.05);	//create a sprite with current image at x=.01,y=0.05 of full screen from upper left

	//generate another text image (frees previous image) and create a sprite from it
	ImageText("Video resolution %d x %d, driver name = %s", (int)GetCtlValue(0),(int)GetCtlValue(1),GetCtlString(1)); 
	SpriteAllocate(.01,.20);

	ImageText("Observed frame rate(Hardware refresh rate) = %06.2fHz. Render rate (Software draw rate) = %7.2fHz. Dropped frames = %d",GetCtlValue(2),GetCtlValue(3),(int)GetCtlValue(4));
	SpriteAllocate(.01,.25);

	//warn user if OpenGL vertical refresh sync is not enabled
	{
		float warninghz = 125.;
		if (GetCtlValue(2) > warninghz)
		{
			DisplayFont(0,NULL,22,TTF_STYLE_NORMAL);
			DisplayText(.01,.50,"WARNING: This observed frame rate normally indicates that OpenGl Vertical Refresh is disabled.\n"
				"Please enable the Vertical Refresh option in your OpenGL driver.");
			DisplayFont(-1, NULL, 0, 0); //reselect default font
		}
	}

	ImageText("Please press keys 1 to 8 (in order) to continue the demonstration.");
	SpriteAllocate(.01,.90);

	DisplayControl(1);	//set sprite list for display
}

void Key_h(void)
{
	// help page

	DisplayControl(0);

	SetColor(2, .5, .5, .5);

	ImageAllocate(100,100);	//create an empty 100*100 pixel image
	ImageColor(0,0,0);
	ImageFillRect(0,0,100,100); //fill a rectange im the image (whole image) with the foreground color
	SpriteAllocate(100,100);  //create a sprite from the image at pixel 100,100
	SpriteMotion(-10,0,-1,-1,-1,-1); //program sprite to move -10 pixels per frame in the x direction

	ImageColor(255,255,255);

	DisplayText(.01, .3, "Motion Artifact Pattern Generator (MAPG) demonstration program help page:\n\n"
		"MAPG generates frame synchronous displays of field programmable test patterns to demonstrate motion artifacts.\n\n"
		"MAPG is controlled entirely by the keyboard:\n\n"
		"h - help - this screen\n"
		"i - information on the current status of MAPG - please press this key next.\n"
		"1 to 7 - demonstration patterns: please press these keys in order to demonstate some MAPG capabilities.\n"
		"p - pause/continue (toggle between running and stopped)\n"
		"s - single step frame (use 'p' to continue): this may be used to see the frame by frame rendering of the moving patterns.\n"
		"escape - exit MAPG\n\n"
		"Pause, Single Step, and Exit key support are buit into the MAPG executable: all other keys above are implemented in mapgdemo.c" );

	DisplayControl(1);
}


void Key_1(void)
{
	DisplayControl(0);
	SetColor(2, 1, 1, 1);

	SetColor(0, 0, 0, 0);
	DisplayText(.01,.01,"Perceived motion blur due to human eye tracking:");

	ImageAllocate(.1,.1);
	ImageColor(0,0,0);
	ImageFillRect(0,0,.999,.999);
	SpriteAllocate(0,.1);
	SpriteMotion(-20,0,-1,-1,-1,-1);
	SpriteMotionPhase(0,2);	//move sprite every other frame

	SpriteAllocate(0,.25);
	SpriteMotion(-10,0,-1,-1,-1,-1);

	SpriteAllocate(0,.40);
	SpriteMotion(-5,0,-1,-1,-1,-1);

	ImageText("Above box is moving 20 pixels every two frames                                                     X");
	SpriteAllocate(.01,.20);
	ImageText("Above box is moving 10 pixels each frame");
	SpriteAllocate(.01,.35);
	ImageText("Above box is moving 5 pixels each frame");
	SpriteAllocate(.01,.50);

	DisplayText(.01,.60,
		"The display refresh rate imposes a fundamental limit on perceived motion blur:\n"
		"The moving squares above change position by multiple display pixels each frame update,\n"
		"but the human eye moves smoothly while trying to track the 'jumping' edge of the boxes.\n"
		"The difference between the actual position of the box at any time and the position expected by the human eye is seen as motion blur.\n\n"
		"If you fix your eye on the 'X' below the top box, you may be able to see the 'jumping' edges more clearly as the boxes move by.\n\n"
		"The middle box above displays the perceived motion blur intrinsic to the current refresh rate.\n"
		"The top box moves twice as far, but half as often: This shows you what you would see with a slower refresh rate.\n"
		"If you can imagine the bottom box moving twice as quickly (but with the edges just as clear),\n"
		"you can see how this display would look operating at twice the frame rate.\n");

	DisplayControl(1);
}



void key2boxtext(void)
{
	ImageText("Above black box is moving %d pixels each frame on a 40 percent grey background (press +/- to change)",(int)(abs(GetCtlValue(20103))));
}

int key2boxsprite=-1;
void Key_2(void)
{
	DisplayControl(0);
	SetColor(2, .4, .4, .4);

	SetColor(0, 0, 0, 0);
	DisplayText(.01,.01,"Motion blur due to pixel response time:");

	ImageAllocate(.1,.1);
	ImageColor(0,0,0);
	ImageFillRect(0,0,.999,.999);
	SpriteAllocate(0,.1);
	SetCtlValue(20103,-10);
	SpriteMotion(20103,0,-1,-1,-1,-1);
	key2boxtext();
	key2boxsprite = SpriteAllocate(.01,.20);

	ImageLoad("rise2.bmp");
	SpriteAllocate(.4,.4);


	DisplayText(.01,.7,
		"In addition to the limits imposed by the refresh rate, the response time of the individual display pixels can also cause motion artifacts.\n\n"
		"For example, if you see a difference between the motion blur width of the leading and trailing edges in the box above, the difference may be caused\n"
		"by a difference between the rise and fall response of the individual pixels.\n\n"
		"This difference may appear even on displays where the rise and fall time components of the overall response time are identical:\n"
		"The response time is typically measured between the 10 percent and 90 percent points on the rise/fall curves,\n"
		"but the region below 10 percent and above 90 percent can also generate noticeable motion artifacts.\n");

	DisplayControl(1);
}

int z=100;

int zcred=0;
int zcgrn=0;
int zcblu=0;
void zcb(int phase)
{
	ImageAllocate(z,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,z,z);
	{
		int r,c;
		ImageColor(zcred,zcgrn,zcblu);
		for (r=0; r<z; r++)
		{
			for (c=0; c<z; c++)
			{
				if ((r+c+phase)&1 != 0)
					ImageFillRect(c,r,1,1);
			}
		}
	}
}

void zhl(int phase)
{
	ImageAllocate(z,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,z,z);
	{
		int r;
		ImageColor(zcred,zcgrn,zcblu);
		for (r=phase; r<z; r+=2)
		{
			ImageFillRect(0,r,z,1);
		}
	}
}

void zvl(int phase)
{
	ImageAllocate(z,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,z,z);
	{
		int c;
		ImageColor(zcred,zcgrn,zcblu);
		for (c=phase; c<z; c+=2)
		{
			ImageFillRect(c,0,1,z);
		}
	}
}

void Key_3(void)
{
	int hsize = (int)GetCtlValue(0);
	int vsize = (int)GetCtlValue(1);

	DisplayControl(0);
	SetColor(2, 128, 128, 128);

	//render top half background checkerboard

	ImageAllocate(hsize,vsize/2);
	ImageColor(0,0,0);
	ImageFillRect(0,0,hsize,vsize/2);
	ImageColor(255,255,255);
	{
		int r,c;
		for (r=0; r<vsize/2; r++)
		{
			for (c=0; c<hsize; c++)
			{
				if (((r+c)&1) != 0)
				{
					ImageFillRect(c,r,1,1);
				}
			}
		}
	}
	SpriteAllocate(0,0);

	//render three moving patterns

	zcred = zcgrn = zcblu = 255;
	zvl(0);
	SpriteAllocate(0,.33);
	SpriteMotion(1,0,-1,-1,-1,-1);

	zhl(0);
	SpriteAllocate(.33,.33);
	SpriteMotion(1,0,-1,-1,-1,-1);

	zcb(0);
	SpriteAllocate(.66,.33);
	SpriteMotion(1,0,-1,-1,-1,-1);

	//render three alternating patterns

	if (0)
	{
		zcb(0);
		SpriteAllocate(.25,.10);
		SpriteDisplayPhase(0,2);
		zcb(1);
		SpriteAllocate(.25,.10);
		SpriteDisplayPhase(1,2);

		zvl(0);
		SpriteAllocate(.5,.10);
		SpriteDisplayPhase(0,2);
		zvl(1);
		SpriteAllocate(.5,.10);
		SpriteDisplayPhase(1,2);

		zhl(0);
		SpriteAllocate(.75,.10);
		SpriteDisplayPhase(0,2);
		zhl(1);
		SpriteAllocate(.75,.10);
		SpriteDisplayPhase(1,2);
	}
	else
	{
	  	zcb(0);
		SpriteAllocate(.25,.10);
		SpriteDisplayPhase(0,2);
		SpriteAllocate(.15,.10);
		SpriteDisplayPhase(-3,4);
		zcb(1);
		SpriteAllocate(.25,.10);
		SpriteDisplayPhase(1,2);
		SpriteAllocate(.15,.10);
		SpriteDisplayPhase(-12,4);
		 
		zvl(0);
		SpriteAllocate(.5,.10);
		SpriteDisplayPhase(0,2);
		SpriteAllocate(.4,.10);
		SpriteDisplayPhase(-3,4);
		zvl(1);
		SpriteAllocate(.5,.10);
		SpriteDisplayPhase(1,2);
		SpriteAllocate(.4,.10);
		SpriteDisplayPhase(-12,4);
		
		zhl(0);
		SpriteAllocate(.75,.10);
		SpriteDisplayPhase(0,2);
		SpriteAllocate(.65,.10);
		SpriteDisplayPhase(-3,4);
		zhl(1);
		SpriteAllocate(.75,.10);
		SpriteDisplayPhase(1,2);
		SpriteAllocate(.65,.10);
		SpriteDisplayPhase(-12,4);

	}




	DisplayText(.01,.5,"Asymmetric Rise and Fall Profiles");

	DisplayText(.01,.55,
		"Any asymmetry in the display pixel rise and fall time profiles can cause motion artifacts.\n\n"
		"In this example the background is a 1x1 checkerboard of alternating black and white pixels,\n"
		"and all six displayed boxes are are made from 50 percent black pixels and 50 percent white pixels.\n"
		"If the rise and fall time profiles are symmetric, the target boxes will be indistinguishable from the background\n"
		"(when seen from a sufficient distance).\n"
		"Asymmetry may result in luminance and/or color shifts when compared to the background.\n"
		"These large area luminance and/or color shifts can be a sensitive test of certain motion artifacts.\n\n"
		"You may wish to use the 's' key (and look closely) to see the differences in the test patterns.\n\n"
		"Also try looking at the boxes off-axis.");


	DisplayControl(1);
}

int circlingspriteid=-1;
double cpos=0;
double cspeed = .002;

void RenderSprite(int commandkey, int spriteid)
{
	if ((commandkey == '4') || (commandkey == '5')) 
	{
		if (spriteid == circlingspriteid)
		{
			SetSpritePosition(spriteid,.65+.2*sin(cpos),.5+.25*cos(cpos));
			cpos += cspeed;
		}
	}
}


void Key_4(void)
{
	int hsize = (int)GetCtlValue(0);
	int vsize = (int)GetCtlValue(1);
	int n=160;

	cspeed = .002;

	DisplayControl(0);
	SetColor(2, 0, 0, 0);

	//render top half background checkerboard

	zcred = zcblu = 0;
	zcgrn = 255;

	ImageAllocate(hsize/3,vsize/4);
	ImageColor(0,0,0);
	ImageFillRect(0,0,hsize/3,vsize/4);
	ImageColor(0,255,0);
	{
		int r,c;
		for (r=0; r<vsize/4; r++)
		{
			for (c=0; c<hsize/3; c++)
			{
				if (((r+c)&1) != 0)
				{
					ImageFillRect(c,r,1,1);
				}
			}
		}
	}
	SpriteAllocate(.12,.2);
	DisplayText(.12,.45,
		"Alternating checkerboard, horizontal lines, and vertical lines on checkerboard field");
	  
	DisplayText(.12,.60,
		"Any significant asymmetry in the display pixel rise and fall time profiles can cause wireframe artifacts.\n\n"
		"The horizontal and vertical lines in the moving grids should appear equally bright.\n"
		"(and the alternating checkerboard box should be as bright as the surrounding checkerboard field)\n\n"
		"But even if the horizontal and vertical lines are equally bright, moving wireframes can still display wireframe artifacts.\n\n"
		"The slowly circling grid may display some perceptual motion artifacts even with ideal pixel response:\n"
		"Although the grid is being moved (mostly) as smoothly as possible on this display,\n"
		"the horizontal and vertical steps per frame vary as the grid circles, causing eye tracking problems.\n\n"
		"You may use the numeric pad plus and minus keys to speed up or slow down the circling grid.");

	//render h,v, checkerboard alternating fields
	zcb(0);
	SpriteAllocate(.15,.25);
	SpriteDisplayPhase(0,2);
	zcb(1);
	SpriteAllocate(.15,.25);
	SpriteDisplayPhase(1,2);

	zhl(0);
	SpriteAllocate(.25,.25);
	SpriteDisplayPhase(0,2);
	zhl(1);
	SpriteAllocate(.25,.25);
	SpriteDisplayPhase(1,2);

	zvl(0);
	SpriteAllocate(.35,.25);
	SpriteDisplayPhase(0,2);
	zvl(1);
	SpriteAllocate(.35,.25);
	SpriteDisplayPhase(1,2);


	//render green grid
	ImageAllocate(n,n);
	ImageColor(0,0,0);
	ImageFillRect(0,0,n,n);
	{
		int i;
		ImageColor(0,255,0);
		for (i=0; i<n; i+=n/10)
			ImageFillRect(0,i,n,1);
		ImageFillRect(0,n-1,n,1);
		for (i=0; i<n; i+=n/10)
			ImageFillRect(i,0,1,n);
		ImageFillRect(n-1,0,1,n);
	}
	SpriteAllocate(0,0);
	SetCtlValue(20101,1);
	SpriteMotion(20101,0,-1,-1,-1,-1);
	SpriteAllocate(0,0);
	SetCtlValue(20102,1);
	SpriteMotion(0,20102,-1,-1,-1,-1);
	SpriteAllocate(0,0);
	SetCtlValue(20104,1);
	SpriteMotion(20104,20104,-1,-1,-1,-1);
	circlingspriteid = SpriteAllocate(.5,.5);

	//indicate display time position update needed
	//CustomMotion(spriteid) will be called each frame just before this sprite is displayed
	//so that the sprite position can be programmatically changed
	SpriteMotion(0,0,0,0,0,0);

	DisplayText(.12,.55,"Wireframe Artifacts");
	DisplayControl(1);
}



void Key_6(void)
{
	DisplayControl(0);
	SetColor(2, 1, 1, 1);
	SetColor(0, 0, 0, 0);
	DisplayText(.01,.01,
"MAPG Structure and Customization:\n\n"
"When MAPG is started it creates a full screen display at the current resolution and frame rate using Open GL.\n"
"It then reads demo.c, the interpreted C control code, which defines screens to be displayed when non-reserved keys are pressed.\n"
"When a key is hit, the corresponding function in demo.c is called to read or create images,\n"
"  which are then converted to a list of sprites to be displayed.\n\n"
"Although creating the sprite list in interpreted C is fairly slow, the sprite list itself can be rendered very quickly on each new frame\n\n"
"Please read demo.c for more information:\n"
"   you may change this file as desired to generate new screens.\n"
" ");
}		

void Key_7(void)
{
	DisplayControl(0);
	SetColor(2, 1, 1, 1);
	SetColor(0, 0, 0, 0);
	DisplayText(.01,.01,
"MAPG Portability:\n\n"
"MAPG is designed to be highly portable:\n"
"  Display output is performed by OpenGl, which is supported by many drivers.\n"
"  Windows systems can also select DirectX\n"
"  All control input (keyboard only) is performed by SDL.\n"
"  Fonts are rendered using the SDL addon SDL_ttf, which uses FreeType & Zlib1.\n"
"  The free font vera.ttf is included in this distribution.\n"
"  Field programmability is provided by the embedded C interpreter.\n\n"
"This particular distribution was compiled using a Windows specific toolchain.\n"
"The next steps in porting to other platform are:\n"
" 1. Build and test in Windows using a portable toolchain.\n"
" 2. Rebuild and test in Linux (x86).\n"
" 3. Rebuild and test for other platforms.\n"
" ");
}		


void Key_8(void)
{
	double z=50;
	double zz;
	int hsize = (int)GetCtlValue(0);
	int vsize = (int)GetCtlValue(1);

	DisplayControl(0);

	SetColor(2, .5, .5, .5);

	SetColor(0, 0, 0, 0);
	DisplayText(.01,.01,"Some MAPG capabilities");


	ImageLoad("test1.bmp");
	SpriteAllocate(400,100);
	SpriteMotion(-1,-2,-1,-1,-1,-1);

	ImageAllocate(30,30);
	ImageColor(255,0,0);
	ImageFillRect(0,0,30,30);
	SpriteAllocate(0,0);
	SpriteMotion(-1,-1,-1,-1,-1,-1);

	//note that you can create multiple sprites from one image
	SpriteAllocate(100,100);
	SpriteMotion(10,1,-1,-1,-1,-1);

	ImageAllocate(10,20);
	ImageColor(255,255,255);
	ImageFillRect(0,0,10,20);
	SpriteAllocate(.5,.5);
	SpriteMotion(.5,.5,-1,-1,-1,-1);

	zz = z*2;
	ImageAllocate(z,z);
	ImageColor(255,0,0);
	ImageFillRect(0,0,z,z);
	SpriteAllocate(zz,zz);

	zz += z*2;
	ImageAllocate(z,z);
	ImageColor(0,255,0);
	ImageFillRect(0,0,z,z);
	SpriteAllocate(zz,zz);

	zz += z*2;
	ImageAllocate(z,z);
	ImageColor(0,0,255);
	ImageFillRect(0,0,z,z);
	SpriteAllocate(zz,zz);

	zz += z*2;
	ImageAllocate(z,z);
	ImageColor(255,255,255);
	ImageFillRect(0,0,z,z);
	SpriteAllocate(zz,zz);


	zz += z*2;
	ImageAllocate(z,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,z,z);
	SpriteAllocate(zz,zz);

	zz += z*2;
	z*=2;
	ImageAllocate(hsize,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,.9999,.9999);
	{
		int c;
		ImageColor(128,128,128);
		for (c=0; c<hsize; c+=2)
		{
			ImageFillRect(c,0,1,z);
		}
	}
	SpriteAllocate(0,zz);

	z+=5;
	ImageAllocate(z,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,z,z);
	{
		int c;
		ImageColor(128,128,128);
		for (c=0; c<z; c+=2)
		{
			ImageFillRect(c,0,1,z);
		}
	}
	ImageStore("testwrite.bmp");
	SpriteAllocate(zz,zz);
	SpriteMotion(1,0,-1,-1,-1,-1);

	SpriteAllocate(50,zz);
	SpriteDisplayPhase(0,2);

	ImageAllocate(z,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,z,z);
	{
		int c;
		ImageColor(128,128,128);
		for (c=1; c<z; c+=2)
		{
			ImageFillRect(c,0,1,z);
		}
	}
	SpriteAllocate(50,zz);
	SpriteDisplayPhase(1,2);
				
	z-= 5;

	zz += z*2;
	ImageAllocate(z,z);
	ImageColor(0,0,0);
	ImageFillRect(0,0,z,z);
	{
		int c;
		ImageColor(128,128,128);
		for (c=0; c<z; c+=10)
		{
			ImageFillRect(c,0,1,z);
		}
	}
	SpriteAllocate(zz,zz);

	ImageLoad("test2.bmp");
	SpriteAllocate(800,100);

	ImageColor(128,255,128);
	DisplayFont(0,NULL,40,TTF_STYLE_BOLD);
	ImageText("Text");
	SpriteAllocate(1400,100);
	SpriteMotion(1,1,-1,-1,-1,-1);
	DisplayFont(-1,0,0,0);

	{
		static int displayed=0;
		if (!displayed)
		{
			//set a test warning/error message
			SetCtlString(0,"This is a %s error: it will be displayed on its own screen,\noverriding all other displays,\nuntil some other key is hit,\nwhich clears the warning message\n\nPlease press '8' again to continue","simulated");
			displayed=1;
		}
	}
	DisplayControl(1);
}


//start display with the help screen
//Key_h();  //does nothing - currently overridden by initial license text

int briggsred0 = 255;	//briggs box foreground colors
int briggsgrn0 = 255;
int briggsblu0 = 255;

int briggsred1 = 0;	//briggs box background colors
int briggsgrn1 = 0;
int briggsblu1 = 0;

int briggsred2 = 128;	//briggs test screen background color
int briggsgrn2 = 128;
int briggsblu2 = 128;

int boxsize=0;
void BriggsBox(int pixels, int nreps)
//create an image & fill it with briggs checkerboard
{
	int r,c;
	int n = pixels*nreps;
	boxsize = n;
	ImageAllocate(n,n);
	ImageColor(briggsred1,briggsgrn1,briggsblu1);
	ImageFillRect(0,0,n,n);
	ImageColor(briggsred0,briggsgrn0,briggsblu0);
	for (r=0; r<nreps; r++)
	{
		for (c=0; c<nreps; c++)
		{
			if (((r+c) & 1) == 0)
			{
				ImageFillRect(c*pixels,r*pixels,pixels,pixels);
			}
		}
	}
}

void BriggsCluster(double x, double y, double xmotion, double ymotion)
{
	int spacing = 30;
	int pboxsize;
	double y25;
	double px;

	BriggsBox(40, 3);   //box 10
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	y += boxsize + spacing; 
	BriggsBox(35, 3);   //box 15
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	x += boxsize + spacing; 
	pboxsize = boxsize;
	BriggsBox(30, 3);   //box 20
	y += pboxsize-boxsize;
	pboxsize = boxsize;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	y += boxsize + spacing;
	y25 = y;
	BriggsBox(25, 3);   //box 25
	x += (pboxsize - boxsize);
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	y += boxsize + spacing;
	BriggsBox(20, 3);   //box 30
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	y += 1.1*spacing;
	BriggsBox(15, 3);   //box 35
	x -= boxsize + spacing;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	y += -0.1*spacing;
	BriggsBox(12, 3);   //box 40
	x -= boxsize + spacing;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	x -= 0.5*spacing;
	BriggsBox(10, 5);   //box 45
	y -= boxsize + spacing;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	y = y25;
	x += 0.0*spacing;
	BriggsBox(9, 5);   //box 50
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	x += 0.4*spacing + boxsize;
	BriggsBox(8, 5);   //box 55
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	x += 0.4*spacing + boxsize;
	BriggsBox(7, 5);   //box 60
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	x += 0.1*spacing;
	BriggsBox(6, 5);   //box 65
	y += 0.4*spacing + boxsize;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	x += 0.3*spacing;
	BriggsBox(5, 5);   //box 70
	y += 0.5*spacing + boxsize;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	BriggsBox(4, 5);   //box 75
	x -= 0.25*spacing + boxsize;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	BriggsBox(3, 7);   //box 80
	x -= 0.25*spacing + boxsize;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	BriggsBox(2, 7);   //box 85
	y -= 0.5 * spacing + boxsize;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);

	BriggsBox(1, 7);   //box 90
	x += 0.4*spacing+boxsize;
	SpriteAllocate(x,y);
	SpriteMotion(xmotion,ymotion,-1,-1,-1,-1);
}


void Key_b(void)
{

	DisplayControl(0);
	SetColor(2, briggsred2, briggsgrn2, briggsblu2);

	BriggsCluster(10, 10, 0, 0);
	BriggsCluster(10, 10, 4, 0);
	BriggsCluster(10, 10, 16, 0);
//	BriggsCluster(10, 500, 1, 0);
//	BriggsCluster(10, 500, 2, 0);
//	BriggsCluster(10, 500, 8, 0);

	ImageLoad("greybriggs.bmp");
	SpriteAllocate(10,10);
	SpriteMotion(2,2,-1,-1,-1,-1);

	DisplayText(.05,.95,
		"Briggs-like Targets moving 0,4,&16 pixels per frame.\n");
//		"Briggs Targets: Top row moving 0,4,&16 pixels per frame. Bottom row moving at 1,2,and 8 pixels per frame.\n");
	DisplayControl(1);
}

 void Key_5(void)
{
	int hsize = (int)GetCtlValue(0);
	int vsize = (int)GetCtlValue(1);
	int n=160;

	DisplayControl(0);
	SetColor(2, 0, 0, 0);

	cspeed = .002;

	//render top half background checkerboard

	zcred = zcblu = 0;
	zcgrn = 255;

	ImageAllocate(hsize/3,vsize/4);
	ImageColor(0,0,0);
	ImageFillRect(0,0,hsize/3,vsize/4);
	ImageColor(0,255,0);
	{
		int r,c;
		for (r=0; r<vsize/4; r++)
		{
			for (c=0; c<hsize/3; c++)
			{
				if (((r+c)&1) != 0)
				{
					ImageFillRect(c,r,1,1);
				}
			}
		}
	}
	SpriteAllocate(.12,.2);
	DisplayText(.12,.45,
		"Alternating checkerboard, horizontal lines, and vertical lines on checkerboard field");

	//render h,v, checkerboard alternating fields
	zcb(0);
	SpriteAllocate(.15,.25);
	SpriteDisplayPhase(0,2);
	zcb(1);
	SpriteAllocate(.15,.25);
	SpriteDisplayPhase(1,2);

	zhl(0);
	SpriteAllocate(.25,.25);
	SpriteDisplayPhase(0,2);
	zhl(1);
	SpriteAllocate(.25,.25);
	SpriteDisplayPhase(1,2);

	zvl(0);
	SpriteAllocate(.35,.25);
	SpriteDisplayPhase(0,2);
	zvl(1);
	SpriteAllocate(.35,.25);
	SpriteDisplayPhase(1,2);


	//render green grid
	ImageAllocate(n,n);
	ImageColor(0,0,0);
	ImageFillRect(0,0,n,n);
	{
		int i,j,di,dj;
		int n2 = n/2;
		double d,d2;
		for (i=0; i<n; i++)
		{
			for (j=0; j<n; j++)
			{
				di = i-n2;
				dj = j-n2;
				d = di*di + dj*dj;
				d2 = .5 + .5*sin(d*.015);
				ImageColor(0,255*d2,0);
				ImageFillRect(i,j,1,1);
			}
 		}
	}
	SetCtlValue(200,0);
	SpriteAllocate(0,0);
	SpriteMotion(1,0,-1,-1,-1,-1);
	SpriteAllocate(0,0);
	SpriteMotion(0,1,-1,-1,-1,-1);
	SpriteAllocate(0,0);
	SpriteMotion(1,1,-1,-1,-1,-1);
	circlingspriteid = SpriteAllocate(.5,.5);

	//indicate display time position update needed
	//CustomMotion(spriteid) will be called each frame just before this sprite is displayed
	//so that the sprite position can be programmatically changed
	SpriteMotion(0,0,0,0,0,0);

	ImageColor(0,255,0);
	DisplayText(.12,.55,"Zoneplates");

	DisplayText(.12,.60,
		"Zoneplates often demonstrate spatial artifacts even when stationary:\n"
		"Moving zoneplates may exibit additional or accentuated artifacts.");

	DisplayControl(1);
}

void Key_Pairs(int commandkey, int keypaircode)
{
	//Log("Key_paired(%d, %d)\n",commandkey,keypaircode);
	if ((commandkey == '4') || (commandkey == '5')) 
	{
		if (keypaircode == 3)
			cspeed *= 1.1;
		if (keypaircode == -3)
			cspeed *= 0.9;
	 }
	if (commandkey == '2')
	{
		key2boxtext();
		ReplaceSpriteImage(key2boxsprite);
	}
}

void x2(int n, double offset)
//vertical sine bars with offset
{
	ImageAllocate(n,n);
	ImageColor(0,0,0);
	ImageFillRect(0,0,n,n);
	{
		int i;
		for (i=0; i<n; i++)
		{
			double d2 = .5 + .5*sin(1.5*i+offset);
			ImageColor(0,255*d2,0);
			ImageFillRect(i,0,1,n);
		}
	}
}

void Key_x(void)
{
	int hsize = (int)GetCtlValue(0);
	int vsize = (int)GetCtlValue(1);
	int n=100;

	zcred = zcgrn = zcblu = 255;

	DisplayControl(0);
	SetColor(2, 128, 128, 128);

	//render top half background checkerboard

	ImageAllocate(hsize,vsize/2);
	ImageColor(0,0,0);
	ImageFillRect(0,0,hsize,vsize/2);
	ImageColor(255,255,255);
	{
		int r,c;
		for (r=0; r<vsize/2; r++)
		{
			for (c=0; c<hsize; c++)
			{
				if (((r+c)&1) != 0)
				{
					ImageFillRect(c,r,1,1);
				}
			}
		}
	}
	SpriteAllocate(0,0);

	//render three alternating patterns

	zvl(0);
	SpriteAllocate(.25,.10);
	SpriteMotion(8,0,-1,-1,-1,-1);
	SpriteMotionPhase(0,2);
	SpriteDisplayPhase(0,2);

	zhl(1);
	SpriteAllocate(.25,.10);
   	SpriteMotion(8,0,-1,-1,-1,-1);
	SpriteMotionPhase(0,2);
	SpriteDisplayPhase(1,2);

	zvl(0);
	SpriteAllocate(.50,.10);
	SpriteMotion(.5,0,-1,-1,-1,-1);

	//single phase motion

	x2(n, 0);
	SpriteAllocate(.25,.20);
	SpriteMotion(.5,0,-1,-1,-1,-1);

	x2(n, 0);
	SpriteAllocate(.50,.20);
	SpriteMotion(1.5,0,-1,-1,-1,-1);

	x2(n, 0);
	SpriteAllocate(.75,.20);
	SpriteMotion(2.5,0,-1,-1,-1,-1);


	//two phase motion

	x2(n, 0);
	SpriteAllocate(.25,.30);
	SpriteMotion(.5,0,-1,-1,-1,-1);	 //.5 pixels per frame
	SpriteDisplayPhase(1,2);		 //second phase

	x2(n, .5);
	SpriteAllocate(.25,.30);
	SpriteMotion(.5,0,-1,-1,-1,-1);
	SpriteDisplayPhase(0,2);		//first phase


	x2(n, 0);
	SpriteAllocate(.50,.30);
	SpriteMotion(1.5,0,-1,-1,-1,-1);
	SpriteDisplayPhase(1,2);

	x2(n, .5);
	SpriteAllocate(.50,.30);
	SpriteMotion(1.5,0,-1,-1,-1,-1);
	SpriteDisplayPhase(0,2);


	x2(n, 0);
	SpriteAllocate(.75,.30);
	SpriteMotion(2.5,0,-1,-1,-1,-1);
	SpriteDisplayPhase(1,2);

	x2(n, .5);
	SpriteAllocate(.75,.30);
	SpriteMotion(2.5,0,-1,-1,-1,-1);
	SpriteDisplayPhase(0,2);


	DisplayText(.01,.5,"Two Phase Render Test");
	DisplayControl(1);
}
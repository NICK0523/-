function [d,C] = get_d_C(cgats, Lsteps, hsteps)

%Get the standard tesselation
RGB=[cgats.RGB_R,cgats.RGB_G,cgats.RGB_B];
[TRI_ref, RGB_ref] = make_tesselation(unique(RGB));
%make a look-up table which maps rows in RGB_ref to rows in RGB
map = map_rows(RGB_ref,RGB);
%Get the standard tesselation referencing rows or RGB instead of RGB_ref 
TRI=map(TRI_ref);
%get the CIELAB data in Z
Z=[cgats.LAB_A,cgats.LAB_B,cgats.LAB_L];

%Find the minmum and maxmum L* in each triangle
%Get a matrix of all L values of all TRI vertices
TRI_L=reshape(Z(TRI,3),size(TRI));
%Then get the max and min
Max_L=max(TRI_L,[],2);
Min_L=min(TRI_L,[],2);

%Define L* and Hue of ray vector boundaries
L=(0:100/Lsteps:100)';
Hue=(0:2*pi/hsteps:2*pi)';
%Note that rays will be defined at the mid-points of these boundaries

%Initiate the output cell arrays
%Note: cell arrays must be used, as the list of intersections for each
%vector can be of variable length
d=cell(Lsteps,hsteps);
C=d;

%For every step in L*
for iL=1:Lsteps
    
    %The the ray L*, which is the mid-point
    Lmid=(L(iL)+L(iL+1))/2;
    %Set the ray origin
    orig=[0 0 Lmid];

    %Get a list of all tiles which lie at all within the L* boundaries
    IX=find(Lmid>=Min_L&Lmid<=Max_L);
    
    %Repeat the origin for element-wise calculations - not needed in later matlab versions. 
	orig=repmat(orig,size(IX));
    %get vectors to each vertex of each tile
    vert0=Z(TRI(IX,1),:);
    vert1=Z(TRI(IX,2),:);
    vert2=Z(TRI(IX,3),:);
    
    % find vectors for two edges sharing vert0 of each tile
    edge1 = vert1-vert0;    
    edge2 = vert2-vert0;
    % and the vector to the origin of each tile
    o  = orig -vert0;       
    % pre-calculate the cross products outside the inner loop
    e2e1 = cross(edge2, edge1, 2);
    e2o = cross(edge2, o, 2);
    oe1 = cross(o, edge1, 2);
    % and the one determinant which does not involve 'dir'
    e2oe1 = sum(edge2.*oe1, 2);
    % drop the L* coordinate as the 'dir' vector always has dL*=0
    e2e1=e2e1(:,1:2);
    e2o=e2o(:,1:2);
    oe1=oe1(:,1:2);
    
    %for every step in Hue
    for iHue=1:hsteps

        %the unit vector represented by L* and Hue (just the da*,db* terms)
        Hmid=(Hue(iHue)+Hue(iHue+1))/2;
        dir=[sin(Hmid);cos(Hmid)]; 
        
        idet   = 1./(e2e1*dir); % denominator for all calculations
        u    = e2o*dir.*idet;   % 1st barycentric coordinate
        v    = oe1*dir.*idet;   % 2nd barycentric coordinate
        t    = e2oe1.*idet;     % 'position on the line' coordinate

        %Find the tiles for which the ray passes within their edges
        %The triangle perimiter is defined by edges u=0, v=0 and u+v=1
        %plus the addition of a tolerance to deal with round-off errors
        ix= u>=0 & v>=0 & u+v<=1 & t>=0;
        %If no tile was found, add some tolerance and try again.
        if (sum(ix)==0)
            ix= u>=-0.001 & v>=-0.001& u+v<=1.001 & t>=0;
        end
        %calculate and store the d and C* values for each intersection (if any)
        d{iL,iHue}=sign(idet(ix));
        C{iL,iHue}=t(ix);
    end
end
end
function [di,Ci] = intersect_d_Cs(d1,C1,d2,C2)
%INTERSECT_D_CS intersects two sets of d,C values
%  [di,Ci] = intersect_d_Cs(d1,C1,d2,C2)
%    returns di,Ci which is the intersection of d1,C1 and d2,C2.

%call the intersect function for each set of d and C* values
[di,Ci] = cellfun(@intersect,d1,C1,d2,C2,'UniformOutput',false);
end

function [di,Ci]=intersect(d1,C1,d2,C2)
    %concat all d and C values;
    di=[d1;d2];
    Ci=[C1;C2];
    %and d values separated into quadrants.
    %the columns of dt show where the each gamut is entered and exited
    dt=[d1 0*d1;0*d2 d2];
    %get the indices of a descending sort of all C values
    [~,i]=sort(Ci,'descend');
    %the columns of cumsum(dt) will show for each gamut where the ray
    %vector is inside (=1) or outside (=0).
    %t shows where the vector is inside or outside both gamuts
    t=min(cumsum(dt(i,:)),[],2);
    %calculate which indices if di,Ci to keep.
    %diff t indicates where there are transitions for the intersected gamut
    %i with then be the list of transitions to keep, in C order.
    i=i([false; diff(t)~=0]);
    di=di(i);
    Ci=Ci(i);
end

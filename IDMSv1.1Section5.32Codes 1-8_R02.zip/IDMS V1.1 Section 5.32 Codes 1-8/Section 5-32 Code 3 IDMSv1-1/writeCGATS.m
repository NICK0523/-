function writeCGATS(cgats, filename)
%WRITECGATS Writes an ASCII CGATS data file
%    writeCGATS(cgats, filename)
%  the cgats structure must have the following format
%    cgats.fmt = cell array of char arrays containing the data formats
%    cgats.headers = cell array of header lines to write before BEGIN_DATA_FORMAT
%    There will also be a property named after each format string
%      which is a column vector of data

%open a new file to write
f=fopen(filename,'w');
%write out the headers
fprintf(f,'%s\n',cgats.headers{:});
%write out the data format
fprintf(f,'BEGIN_DATA_FORMAT\n%s\nEND_DATA_FORMAT\n',strjoin(cgats.fmt));
%build a data array from the format names and their properties in cgats
data=cell2mat(cellfun(@(k) cgats.(k),cgats.fmt,'UniformOutput',false));
%write out the set count then all of the data
fprintf(f,'NUMBER_OF_SETS %d\n',size(data,1));
fprintf(f,'BEGIN_DATA\n');
fprintf(f,[repmat('%g ',1,size(data,2)-1) '%g\n'],data');
fprintf(f,'END_DATA\n');
fclose(f);
end


function make_rgb_signals(file_name,n,max)
%MAKE_RGB_SIGNALS calculate the input signal values for the reference set of 602
%colors comprising a linear grid on each face of the RGB cube.
%   make_rgb_signals(file_name) returns RGB values with the default 11x11 grid size values 0..255.
%   make_rgb_signals(file_name,n) as above with an n x n grid size.
%   make_rgb_signals(file_name,n,max) as above with an n x n grid size and values from 0..max
%   make_rgb_signals(file_name,V) as above with the specified grid values.
%     n, max are scalars
%     V is a vector of values
%     file_name is a char array

V=[];
if nargin<3, max=255; end
if nargin<2
    n=11;
elseif ~isscalar(n)
    V=n;
end
%V was not supplied, calculate it from n and max values
if (isempty(V))
    V=floor((0:1/(n-1):1)*max);
end
%make the tesselation
[~,rgb] = make_tesselation(V);
%ensure there are no duplicate rgb values
rgb=unique(rgb,'rows');

%write out the file
cgats=[];
cgats.headers={'CGATS.17','nFORMAT_VERSION\t2'};
cgats.fmt={'SampleID','RGB_R','RGB_G','RGB_B'};
cgats.SampleID=(1:size(rgb,1))';
cgats.RGB_R=rgb(:,1);
cgats.RGB_G=rgb(:,2);
cgats.RGB_B=rgb(:,3);
writeCGATS(cgats,file_name);
end


function V = get_volume(filename)
%GET_VOLUME Calculates the volume of a gamut envelope
%   getVolume(file) returns the volume
%     file should be the output from a call to make_gamut_envelope

%read the CGATS file
cgats = readCGATS(filename);

%calculate the d and C* values for the given L* and h* steps
hsteps=360;
Lsteps=100;
[d,C] = get_d_C(cgats, Lsteps, hsteps);

%calculate the scaled sum for each L* and h* step
%applying the scaling factor AFTER summing rather than before per-element
volmap=cellfun(@(d,C) sum(d.*C.^2),d,C);
%sum the values and correct the scaling;
V=sum(volmap(:))*100*pi/(Lsteps*hsteps);
end

function [V] = get_intersection_volume(file1,file2)
%GET_INTERSECTION_VOLUME Calculates the volume of the intersection of two gamut envelopes
%   get_intersection_volume(file1,file2) returns the intersected volume
%     files should be the output from calls to make_gamut_envelope

%read the CGATS files
cgats1 = readCGATS(file1);
cgats2 = readCGATS(file2);

%calculate the d and C* values for the given L* and h* steps
hsteps=360;
Lsteps=100;
[d1,C1] = get_d_C(cgats1, Lsteps, hsteps);
[d2,C2] = get_d_C(cgats2, Lsteps, hsteps);
%intersect the two sets of d and C values
[di,Ci] = intersect_d_Cs(d1,C1,d2,C2);

%calculate the scaled sum for each L* and h* step
%applying the scaling factor AFTER summing rather than before per-element
volmap=cellfun(@(d,C) sum(d.*C.^2),di,Ci);
%sum the values and correct the scaling;
V=sum(volmap(:))*100*pi/(Lsteps*hsteps);
end


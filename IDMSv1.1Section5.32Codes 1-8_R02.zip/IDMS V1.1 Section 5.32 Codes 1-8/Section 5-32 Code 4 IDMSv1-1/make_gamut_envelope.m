function CIELAB =  make_gamut_envelope (input_file, output_file)
%MAKE_GAMUT_ENVELOPE convert a CGATS file containing XYZ data to CIEL*a*b*
%with bradford chromatic adaption to D50
%  make_gamut_file(input_file, output_file) reads XYZ data from the input
%    CGATS file and creates a new CGATS file with the CIEL*a*b* data
%  cielab = make_gamut_file(...) returns the CIEL*a*b* data in a matrix

cgats = readCGATS(input_file);

%build the XYZ and RGB arrays
XYZ=[cgats.XYZ_X,cgats.XYZ_Y,cgats.XYZ_Z];
RGB=[cgats.RGB_R,cgats.RGB_G,cgats.RGB_B];

%find the reference max RGB (don't assume it is 8-bit, for example)
RGBmax = max(RGB(:));
%find the white point
XYZn = XYZ(all(RGB==RGBmax,2),:);

%Get a D50 white point of equivalent luminance
D50=[0.9642, 1, 0.8249]*XYZn(2);

%Chromatically adapt CIE XYZ to D50 using CIECAM02 CAT
%assuming full adaptation and using the 'Bradford' coefficients
%if XYZn is already D50 this is harmless, and a check will fail without a
%reasonable tolerance.  Simplest is just to always adapt.
XYZ = camcat_cc(XYZ, XYZn, D50);

%calculate CIELAB
CIELAB = xyz2lab(XYZ,D50);

%change the list of values to output - excluding XYZ, including LAB
cgats.fmt={'RGB_R','RGB_G','RGB_B','LAB_L','LAB_A','LAB_B'};
if isfield(cgats,'SampleID')
    cgats.fmt=[{'SampleID'},cgats.fmt];
end
%assign the LAB values to the appropriate property
cgats.LAB_L=CIELAB(:,1);
cgats.LAB_A=CIELAB(:,2);
cgats.LAB_B=CIELAB(:,3);

writeCGATS(cgats,output_file);
end